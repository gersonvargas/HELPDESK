// wuclient.c
// Weather update client
// Connects SUB socket to tcp://localhost:5556
// Collects weather updates and finds avg temp in zipcode 
//
#include <zhelpers.h>

int main (int argc, char *argv []) {
  void *context = zmq_ctx_new ();

  //  Socket to talk to server
  printf ("Collecting updates from weather server...\n"); 
  void *subscriber = zmq_socket (context, ZMQ_SUB);
  int rc = zmq_connect (subscriber, "tcp://localhost:5556"); 
  //assert (rc == 0);

  //  Subscribe to zipcode, default is NYC, 10001
  char *filter = (argc > 1)? argv [1]: "";
  rc = zmq_setsockopt (subscriber, ZMQ_SUBSCRIBE, filter, strlen (filter)); 
 // assert (rc == 0);

  //  Process 100 updates
  int update_nbr;
  long total_temp = 0;
  int zipcode, temperature, relhumidity;
  
  int carton [20];
  int carton2 [20];
	   int cantidad= 0;
	     for (int i = 0; i < 20; i++) {
			carton [i]=randof(25); 
		}
   int gane=0;
   
  while (gane < 20) {
	  
	  for (int i = 0; i < 20; i++) {
			printf ("Imprimiendo carton '%d' \n",carton [i]);
		}
    char *string = s_recv (subscriber); 
    sscanf (string, "%d \n",&zipcode);
	  
	  
	   //verificar si ya gano
	   for (int i = 0; i < 20; i++) {
		   if(zipcode==carton [i]){
			   gane++;
			   printf ("casilla '%d' \n",carton [i]);
			   printf ("zipcode '%d' \n",zipcode);
			  } 
		}
	   
    free (string);
  }
  printf ("Eres un ganador!");

  zmq_close (subscriber);
  zmq_ctx_destroy (context); 
  return 0;
}