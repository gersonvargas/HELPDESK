// hwserver.c
// Hello World server
// Binds REP socket to tcp://*:5555
// Expects "Hello" from client, replies with "World" 
//
#include <time.h>
#include <zmq.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
//#include <zhelpers.h>

int main (void) {
  void *context = zmq_ctx_new ();
  //  Socket to talk to clients
  void *responder = zmq_socket (context, ZMQ_REP); 
  zmq_bind (responder, "tcp://*:5555");

  while (1) {
    time_t current_time;
    char* c_time_string;
    current_time = time(NULL);
    c_time_string = ctime(&current_time);
    printf("Current time is %s", c_time_string);


    // Wait for next request from client 
    zmq_msg_t request;
    zmq_msg_init (&request);
    zmq_msg_recv (&request, responder, 0); 
    printf ("Received Hello \n"); 
    
    //  Do some 'work'
    sleep (1);
    //  Send reply back to client
    zmq_msg_t reply;
    zmq_msg_init_size (&reply, 4);
    //memcpy (zmq_msg_data (&reply), "World wonder", 5);

    zmq_msg_t requestd;
    zmq_msg_init_size(&requestd, 100);
    memcpy(zmq_msg_data(&requestd), c_time_string, 100);

    zmq_msg_send (&requestd, responder, 0);
    zmq_msg_close (&requestd);
     zmq_msg_close (&request);
    zmq_msg_close (&reply);
  }
  //  We never get here but if we did, this would be how we end
  zmq_close (responder); 
  zmq_ctx_destroy (context); 
  return 0;
}
