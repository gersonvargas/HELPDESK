// taskintegr.c
// Task sink
// Binds PULL socket to tcp://localhost:5558
// Collects results from workers via that socket //
#include "zhelpers.h" 

int main (void) {

   //  Prepare our context and socket
   void *context = zmq_ctx_new ();
   void *receiver = zmq_socket (context, ZMQ_PULL); 
   zmq_bind (receiver, "tcp://*:5558"); 

   //  Wait for start of batch
   char *string = s_recv (receiver,0); 
   
   int numerofact = atoi(string);
   printf("recibido %d.",numerofact);
   free (string); 

   //  Start our clock now
   int64_t start_time = s_clock (); 

   //  Process 100 confirmations
   int task_nbr;
   int suma=0;
   for (task_nbr = 0; task_nbr < numerofact; task_nbr++) { 
     char *string = s_recv (receiver,0); 
     int numerofact = atoi(string);
     suma+=numerofact;
     fflush (stdout);
   } 
   //  Calculate and report duration of batch
   printf ("El factorial de: %d es: %d  \n",numerofact, suma); 

  zmq_close (receiver); 
  zmq_ctx_destroy (context); 
  return 0; 
}