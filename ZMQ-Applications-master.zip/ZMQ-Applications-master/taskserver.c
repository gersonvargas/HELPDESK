// taskserver.c
// Task server
// Binds REP socket to tcp://*:5555
//
#include <zhelpers.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>

void leer_archivo(char *p_archivo)
{
    FILE *fp;
    char *line = NULL;
    size_t len = 0;
    ssize_t read;
    char *res = "";
    fp = fopen(p_archivo, "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

    while ((read = getline(&line, &len, fp)) != -1)
    {
        printf("Retrieved line of length %zu:\n", read);
        printf("%s", line);
        //res+=line;
    }
    printf("%s", line);
    fclose(fp);
    if (line)
        free(line);
}
int main(void)
{
    //leer_archivo("index.html");

    void *context = zmq_ctx_new();

    void *responder = zmq_socket(context, ZMQ_REP);
    zmq_bind(responder, "tcp://*:5555");

    char length[20];

    while (1)
    {
        char *request;
        request = s_recv(responder);
        if (request == NULL)
            continue;

        printf("Received: %s\n", request);

        char *url = strtok(request, " ");
        url = strtok(NULL, " ");

        printf("URL: %s\n", url);

        free(request);

        char *reply = "Hello World";
        sprintf(length, "%d", strlen(reply));

        //enviar al web server

        FILE *fp;
        char *line = NULL;
        size_t len = 0;
        ssize_t read;
        fp = fopen(url, "r");
        if (fp == NULL)
            exit(EXIT_FAILURE);

        while ((read = getline(&line, &len, fp)) != -1)
        {
            printf("Retrieved line of length %zu:\n", read);
            printf("%s", line);
            s_sendmore(responder, line);
        }
        printf("%s", line);
        fclose(fp);
        if (line)
            free(line);

        s_send(responder, reply);
    }

    zmq_close(responder);
    zmq_ctx_destroy(context);
    return 0;
}