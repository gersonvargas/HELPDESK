// taskevent.c
// Task generator
// Binds PUSH socket to tcp://localhost:5557
// Sends batch of tasks to workers via that socket 
//

#include "zhelpers.h" 

int main (void) { 
  void *context = zmq_ctx_new (); 

  //  Socket to send messages on
  void *sender = zmq_socket (context, ZMQ_PUSH); 
  zmq_bind (sender, "tcp://*:5557"); 

  //  Socket to send start of batch message on
  void *sink = zmq_socket (context, ZMQ_PUSH); 
  zmq_connect (sink, "tcp://localhost:5558");

  printf ("Press Enter when the workers are ready: "); 

   int factorial;
    printf("Introduzca el numero que desea calcular el factorial: ");
    scanf("%d", &factorial);
    printf("Gracias");
  getchar ();
  printf ("Sending tasks to workers...\n");

  //  The first message is "0" and signals start of batch
   char update [20];
   sprintf (update, "%d", factorial); 
  s_send (sink, update);

  // Initialize random number generator 
  srandom ((unsigned) time (NULL)); 

  //  Send 100 tasks
  int task_nbr;
  int total_msec = 0; // Total expected cost in msec
  for (task_nbr = factorial; task_nbr >= 1; task_nbr--) { 
    int workload;
    char string [10];
    sprintf (string, "%d", task_nbr); 
    s_send (sender, string); 
     printf ("Se envia el factorial de: %s \n", string); 
  }
  printf ("Total expected cost: %d msec\n", total_msec); 
  //sleep (1); // Give 0MQ time to deliver 

  zmq_close (sink); 
  zmq_close (sender); 
  zmq_ctx_destroy (context); 
  return 0; 
} 