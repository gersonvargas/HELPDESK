// taskwork.c
// Task worker
// Connects PULL socket to tcp://localhost:5557
// Collects workloads from task generator via that socket
// Connects PUSH socket to tcp://localhost:5558
// Sends results to integrator via that socket
//
#include "zhelpers.h"

int main(void)
{
    void *context = zmq_ctx_new();

    //  Socket to receive messages on
    void *receiver = zmq_socket(context, ZMQ_PULL);
    zmq_connect(receiver, "tcp://localhost:5557");

    //  Socket to send messages to
    void *sender = zmq_socket(context, ZMQ_PUSH);
    zmq_connect(sender, "tcp://localhost:5558");

    //  Process tasks forever
    while (1)
    {
        char *string = s_recv(receiver, 0);
        // Simple progress indicator for the viewer
        fflush(stdout);
        printf("%s.", string);

        // Do the work
        int numerofact = atoi(string);
        int i;
        unsigned long long factorial = 1;

        // show error if the user enters a negative integer
        if (numerofact < 0)
            printf("Error! Factorial of a negative number doesn't exist.");
        else
        {
            for (i = 1; i <= numerofact; ++i)
            {
                factorial *= i; // factorial = factorial*i;
            }
            char update [20];
            sprintf (update, "%d", factorial); 
            printf("Factorial of %d = %s \n",numerofact,update);
             s_send(sender, update);
        }

        s_sleep(numerofact);

        free(string);

        //  Send results to integrator
       
    }
    zmq_close(receiver);
    zmq_close(sender);
    zmq_ctx_destroy(context);
    return 0;
}